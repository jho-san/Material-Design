package com.fredy.aplicationuns.Anuncios

data class Anuncio(
    val titulo: String,
    val descripcion: String,
    val imagenResId: Int
)